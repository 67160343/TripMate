require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { Pool } = require('pg');

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

const asyncHandler = fn => (req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
const publicUser = r => ({ id:r.id, username:r.username, email:r.email, display_name:r.display_name, avatar_url:r.avatar_url, created_at:r.created_at });
function signToken(user, sessionId){ return jwt.sign({ sub:user.id, username:user.username, sid:sessionId }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN }); }

async function auth(req,res,next){
  try {
    const h=req.headers.authorization||'';
    if(!h.startsWith('Bearer ')) return res.status(401).json({error:'UNAUTHORIZED',message:'Bearer token required'});
    const decoded=jwt.verify(h.slice(7), JWT_SECRET);
    const s=await pool.query('SELECT * FROM sessions WHERE id=$1 AND user_id=$2 AND revoked_at IS NULL AND expires_at>NOW()',[decoded.sid,decoded.sub]);
    if(!s.rowCount) return res.status(401).json({error:'SESSION_EXPIRED',message:'Session is invalid or expired'});
    const u=await pool.query('SELECT * FROM users WHERE id=$1',[decoded.sub]);
    if(!u.rowCount) return res.status(401).json({error:'USER_NOT_FOUND',message:'User no longer exists'});
    req.user=u.rows[0]; req.session=s.rows[0]; next();
  } catch(e){ return res.status(401).json({error:'INVALID_TOKEN',message:'Invalid or expired token'}); }
}
async function tripAccess(req,res,next){
  const id=Number(req.params.id||req.params.tripId); if(!Number.isInteger(id)) return res.status(400).json({error:'INVALID_ID'});
  const q=await pool.query(`SELECT t.*, tm.role, tm.status FROM trips t LEFT JOIN trip_members tm ON tm.trip_id=t.id AND tm.user_id=$2 WHERE t.id=$1 AND (t.owner_id=$2 OR tm.user_id=$2)`,[id,req.user.id]);
  if(!q.rowCount) return res.status(404).json({error:'TRIP_NOT_FOUND_OR_FORBIDDEN',message:'Trip not found or you are not a member'});
  req.trip=q.rows[0]; next();
}
function validateDateRange(start,end){ const s=new Date(start+'T00:00:00'), e=new Date(end+'T00:00:00'), today=new Date(); today.setHours(0,0,0,0); return {valid:start&&end&&!Number.isNaN(s.getTime())&&!Number.isNaN(e.getTime())&&s>=today&&e>=s}; }

app.get('/health',(req,res)=>res.json({status:'ok',service:'tripmate-api',time:new Date().toISOString()}));

// Authentication
app.post('/api/auth/register', asyncHandler(async(req,res)=>{
  const {username,email,password,display_name}=req.body||{};
  if(!username||!email||!password||!display_name) return res.status(400).json({error:'VALIDATION_ERROR',message:'username, email, password and display_name are required'});
  if(password.length<8) return res.status(400).json({error:'WEAK_PASSWORD',message:'Password must be at least 8 characters'});
  const exists=await pool.query('SELECT id FROM users WHERE username=$1 OR email=$2',[username,email]);
  if(exists.rowCount) return res.status(409).json({error:'DUPLICATE_USER',message:'Username or email already exists'});
  const hash=await bcrypt.hash(password,12);
  const u=(await pool.query('INSERT INTO users(username,email,password_hash,display_name) VALUES($1,$2,$3,$4) RETURNING *',[username,email,hash,display_name])).rows[0];
  const sid=crypto.randomUUID(); await pool.query("INSERT INTO sessions(id,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '7 days')",[sid,u.id]);
  res.status(201).json({user:publicUser(u),token:signToken(u,sid)});
}));

app.post('/api/auth/login', asyncHandler(async(req,res)=>{
  const {login,password}=req.body||{}; if(!login||!password) return res.status(400).json({error:'VALIDATION_ERROR',message:'login and password are required'});
  const q=await pool.query('SELECT * FROM users WHERE username=$1 OR email=$1',[login]);
  if(!q.rowCount || !(await bcrypt.compare(password,q.rows[0].password_hash))) return res.status(401).json({error:'INVALID_CREDENTIALS',message:'Invalid login or password'});
  const u=q.rows[0], sid=crypto.randomUUID(); await pool.query("INSERT INTO sessions(id,user_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '7 days')",[sid,u.id]);
  res.json({user:publicUser(u),token:signToken(u,sid)});
}));
app.post('/api/auth/logout',auth,asyncHandler(async(req,res)=>{await pool.query('UPDATE sessions SET revoked_at=NOW() WHERE id=$1',[req.session.id]);res.json({message:'Logged out'});}));
app.post('/api/auth/change-password',auth,asyncHandler(async(req,res)=>{const {current_password,new_password}=req.body||{};if(!current_password||!new_password||new_password.length<8)return res.status(400).json({error:'VALIDATION_ERROR',message:'Current password and a new password of at least 8 characters are required'});if(!(await bcrypt.compare(current_password,req.user.password_hash)))return res.status(400).json({error:'WRONG_PASSWORD',message:'Current password is incorrect'});const h=await bcrypt.hash(new_password,12);await pool.query('UPDATE users SET password_hash=$1,updated_at=NOW() WHERE id=$2',[h,req.user.id]);await pool.query('UPDATE sessions SET revoked_at=NOW() WHERE user_id=$1',[req.user.id]);res.json({message:'Password changed. Please login again.'});}));

// User management
app.get('/api/me',auth,(req,res)=>res.json({user:publicUser(req.user)}));
app.get('/api/check-username/:name',asyncHandler(async(req,res)=>{const q=await pool.query('SELECT 1 FROM users WHERE LOWER(username)=LOWER($1)',[req.params.name]);res.json({username:req.params.name,available:!q.rowCount});}));
app.get('/api/users',auth,asyncHandler(async(req,res)=>{const page=Math.max(1,Number(req.query.page)||1),limit=Math.min(100,Math.max(1,Number(req.query.limit)||20)),offset=(page-1)*limit;const [rows,count]=await Promise.all([pool.query('SELECT id,username,email,display_name,avatar_url,created_at FROM users ORDER BY id DESC LIMIT $1 OFFSET $2',[limit,offset]),pool.query('SELECT COUNT(*)::int count FROM users')]);res.json({data:rows.rows,pagination:{page,limit,total:count.rows[0].count,total_pages:Math.ceil(count.rows[0].count/limit)}});}));
app.get('/api/users/:id',auth,asyncHandler(async(req,res)=>{const q=await pool.query('SELECT id,username,email,display_name,avatar_url,created_at FROM users WHERE id=$1',[req.params.id]);if(!q.rowCount)return res.status(404).json({error:'USER_NOT_FOUND'});res.json({user:q.rows[0]});}));
app.put('/api/users/:id',auth,asyncHandler(async(req,res)=>{if(Number(req.params.id)!==req.user.id)return res.status(403).json({error:'FORBIDDEN'});const {display_name,email,avatar_url}=req.body;const q=await pool.query('UPDATE users SET display_name=COALESCE($1,display_name), email=COALESCE($2,email), avatar_url=COALESCE($3,avatar_url), updated_at=NOW() WHERE id=$4 RETURNING *',[display_name,email,avatar_url,req.user.id]);res.json({user:publicUser(q.rows[0])});}));
app.delete('/api/users/:id',auth,asyncHandler(async(req,res)=>{if(Number(req.params.id)!==req.user.id)return res.status(403).json({error:'FORBIDDEN',message:'You can only delete your own account'});await pool.query('DELETE FROM users WHERE id=$1',[req.user.id]);res.json({message:'Account deleted'});}));

// Trips
app.post('/api/trips',auth,asyncHandler(async(req,res)=>{const {name,destination,start_date,end_date,description,fund_target}=req.body||{};const d=validateDateRange(start_date,end_date);if(!name||!destination||!d.valid)return res.status(400).json({error:'INVALID_TRIP_DATES',message:'Trip name, destination and valid future date range are required. End date must be on/after start date.'});const c=await pool.connect();try{await c.query('BEGIN');const t=(await c.query('INSERT INTO trips(owner_id,name,destination,start_date,end_date,description,fund_target) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[req.user.id,name,destination,start_date,end_date,description||null,Number(fund_target)||0])).rows[0];await c.query("INSERT INTO trip_members(trip_id,user_id,role,status) VALUES($1,$2,'owner','joined')",[t.id,req.user.id]);await c.query('COMMIT');res.status(201).json({trip:t});}catch(e){await c.query('ROLLBACK');throw e}finally{c.release();}}));
app.get('/api/trips',auth,asyncHandler(async(req,res)=>{const q=await pool.query(`SELECT DISTINCT t.*, CASE WHEN t.owner_id=$1 THEN 'owner' ELSE tm.role END role FROM trips t LEFT JOIN trip_members tm ON tm.trip_id=t.id AND tm.user_id=$1 WHERE t.owner_id=$1 OR tm.user_id=$1 ORDER BY t.start_date`,[req.user.id]);res.json({data:q.rows});}));
app.get('/api/trips/:id',auth,tripAccess,asyncHandler(async(req,res)=>{const [members,activities,accommodations,payments]=await Promise.all([pool.query('SELECT u.id,u.username,u.display_name,tm.role,tm.status,tm.joined_at FROM trip_members tm JOIN users u ON u.id=tm.user_id WHERE tm.trip_id=$1 ORDER BY tm.role DESC,u.display_name',[req.trip.id]),pool.query('SELECT * FROM activities WHERE trip_id=$1 ORDER BY activity_date,start_time NULLS LAST,id',[req.trip.id]),pool.query('SELECT * FROM accommodations WHERE trip_id=$1 ORDER BY check_in',[req.trip.id]),pool.query('SELECT p.*,u.display_name FROM payments p JOIN users u ON u.id=p.user_id WHERE p.trip_id=$1 ORDER BY p.paid_at DESC',[req.trip.id])]);res.json({trip:req.trip,members:members.rows,activities:activities.rows,accommodations:accommodations.rows,payments:payments.rows});}));
app.put('/api/trips/:id',auth,tripAccess,asyncHandler(async(req,res)=>{if(req.trip.owner_id!==req.user.id)return res.status(403).json({error:'OWNER_ONLY'});const {name,destination,start_date,end_date,description,fund_target}=req.body||{};const s=start_date||req.trip.start_date.toISOString().slice(0,10),e=end_date||req.trip.end_date.toISOString().slice(0,10);if(!validateDateRange(s,e).valid)return res.status(400).json({error:'INVALID_TRIP_DATES',message:'Trip dates must be today or later and end date must be on/after start date'});const q=await pool.query('UPDATE trips SET name=COALESCE($1,name),destination=COALESCE($2,destination),start_date=$3,end_date=$4,description=COALESCE($5,description),fund_target=COALESCE($6,fund_target),updated_at=NOW() WHERE id=$7 RETURNING *',[name,destination,s,e,description,fund_target,req.trip.id]);res.json({trip:q.rows[0]});}));
app.delete('/api/trips/:id',auth,tripAccess,asyncHandler(async(req,res)=>{if(req.trip.owner_id!==req.user.id)return res.status(403).json({error:'OWNER_ONLY'});await pool.query('DELETE FROM trips WHERE id=$1',[req.trip.id]);res.json({message:'Trip deleted'});}));

// Members
app.post('/api/trips/:id/members',auth,tripAccess,asyncHandler(async(req,res)=>{if(req.trip.owner_id!==req.user.id)return res.status(403).json({error:'OWNER_ONLY'});const {user_id}=req.body||{};const u=await pool.query('SELECT id,username,display_name FROM users WHERE id=$1',[user_id]);if(!u.rowCount)return res.status(404).json({error:'USER_NOT_FOUND'});try{const q=await pool.query("INSERT INTO trip_members(trip_id,user_id,role,status) VALUES($1,$2,'member','joined') RETURNING *",[req.trip.id,user_id]);res.status(201).json({member:{...q.rows[0],user:u.rows[0]}});}catch(e){if(e.code==='23505')return res.status(409).json({error:'ALREADY_MEMBER'});throw e;}}));
app.delete('/api/trips/:id/members/:userId',auth,tripAccess,asyncHandler(async(req,res)=>{if(req.trip.owner_id!==req.user.id)return res.status(403).json({error:'OWNER_ONLY'});if(Number(req.params.userId)===req.trip.owner_id)return res.status(400).json({error:'CANNOT_REMOVE_OWNER'});await pool.query('DELETE FROM trip_members WHERE trip_id=$1 AND user_id=$2',[req.trip.id,req.params.userId]);res.json({message:'Member removed'});}));

// Activities - date must be inside existing trip range
app.post('/api/trips/:id/activities',auth,tripAccess,asyncHandler(async(req,res)=>{const {title,activity_date,start_time,end_time,category,description,location}=req.body||{};const d=activity_date&&activity_date>=new Date(req.trip.start_date).toISOString().slice(0,10)&&activity_date<=new Date(req.trip.end_date).toISOString().slice(0,10);if(!title||!d)return res.status(400).json({error:'INVALID_ACTIVITY_DATE',message:'Activity date must be one of the dates inside this trip'});if(start_time&&end_time&&start_time>=end_time)return res.status(400).json({error:'INVALID_TIME_RANGE',message:'End time must be after start time'});const q=await pool.query('INSERT INTO activities(trip_id,title,activity_date,start_time,end_time,category,description,location,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *',[req.trip.id,title,activity_date,start_time||null,end_time||null,category||'other',description||null,location||null,req.user.id]);res.status(201).json({activity:q.rows[0]});}));
app.get('/api/trips/:id/activities',auth,tripAccess,asyncHandler(async(req,res)=>{const q=await pool.query('SELECT * FROM activities WHERE trip_id=$1 ORDER BY activity_date,start_time NULLS LAST,id',[req.trip.id]);res.json({data:q.rows});}));
app.put('/api/trips/:id/activities/:activityId',auth,tripAccess,asyncHandler(async(req,res)=>{const {title,activity_date,start_time,end_time,category,description,location}=req.body||{};if(activity_date && (activity_date<new Date(req.trip.start_date).toISOString().slice(0,10)||activity_date>new Date(req.trip.end_date).toISOString().slice(0,10)))return res.status(400).json({error:'INVALID_ACTIVITY_DATE',message:'Activity date must be inside this trip'});if(start_time&&end_time&&start_time>=end_time)return res.status(400).json({error:'INVALID_TIME_RANGE'});const q=await pool.query('UPDATE activities SET title=COALESCE($1,title),activity_date=COALESCE($2,activity_date),start_time=COALESCE($3,start_time),end_time=COALESCE($4,end_time),category=COALESCE($5,category),description=COALESCE($6,description),location=COALESCE($7,location),updated_at=NOW() WHERE id=$8 AND trip_id=$9 RETURNING *',[title,activity_date,start_time,end_time,category,description,location,req.params.activityId,req.trip.id]);if(!q.rowCount)return res.status(404).json({error:'ACTIVITY_NOT_FOUND'});res.json({activity:q.rows[0]});}));
app.delete('/api/trips/:id/activities/:activityId',auth,tripAccess,asyncHandler(async(req,res)=>{const q=await pool.query('DELETE FROM activities WHERE id=$1 AND trip_id=$2 RETURNING id',[req.params.activityId,req.trip.id]);if(!q.rowCount)return res.status(404).json({error:'ACTIVITY_NOT_FOUND'});res.json({message:'Activity deleted'});}));

// Accommodation
app.post('/api/trips/:id/accommodations',auth,tripAccess,asyncHandler(async(req,res)=>{const {name,address,check_in,check_out,price,booking_url}=req.body||{};const s=check_in,e=check_out;const valid=s&&e&&s>=new Date(req.trip.start_date).toISOString().slice(0,10)&&e<=new Date(req.trip.end_date).toISOString().slice(0,10)&&e>=s;if(!name||!valid)return res.status(400).json({error:'INVALID_ACCOMMODATION_DATES',message:'Accommodation dates must be within the trip dates and check-out must be on/after check-in'});const q=await pool.query('INSERT INTO accommodations(trip_id,name,address,check_in,check_out,price,booking_url) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',[req.trip.id,name,address||null,s,e,Number(price)||0,booking_url||null]);res.status(201).json({accommodation:q.rows[0]});}));
app.get('/api/trips/:id/accommodations',auth,tripAccess,asyncHandler(async(req,res)=>{const q=await pool.query('SELECT * FROM accommodations WHERE trip_id=$1 ORDER BY check_in',[req.trip.id]);res.json({data:q.rows});}));
app.put('/api/trips/:id/accommodations/:accommodationId',auth,tripAccess,asyncHandler(async(req,res)=>{const old=(await pool.query('SELECT * FROM accommodations WHERE id=$1 AND trip_id=$2',[req.params.accommodationId,req.trip.id])).rows[0];if(!old)return res.status(404).json({error:'ACCOMMODATION_NOT_FOUND'});const s=req.body.check_in||new Date(old.check_in).toISOString().slice(0,10),e=req.body.check_out||new Date(old.check_out).toISOString().slice(0,10);if(s<new Date(req.trip.start_date).toISOString().slice(0,10)||e>new Date(req.trip.end_date).toISOString().slice(0,10)||e<s)return res.status(400).json({error:'INVALID_ACCOMMODATION_DATES'});const q=await pool.query('UPDATE accommodations SET name=COALESCE($1,name),address=COALESCE($2,address),check_in=$3,check_out=$4,price=COALESCE($5,price),booking_url=COALESCE($6,booking_url),status=COALESCE($7,status) WHERE id=$8 AND trip_id=$9 RETURNING *',[req.body.name,req.body.address,s,e,req.body.price,req.body.booking_url,req.body.status,req.params.accommodationId,req.trip.id]);res.json({accommodation:q.rows[0]});}));
app.delete('/api/trips/:id/accommodations/:accommodationId',auth,tripAccess,asyncHandler(async(req,res)=>{await pool.query('DELETE FROM accommodations WHERE id=$1 AND trip_id=$2',[req.params.accommodationId,req.trip.id]);res.json({message:'Accommodation deleted'});}));

// Fund / payments
app.post('/api/trips/:id/payments',auth,tripAccess,asyncHandler(async(req,res)=>{const {user_id,amount,note}=req.body||{};const payerId=Number(user_id||req.user.id);if(!Number.isInteger(payerId)||payerId<=0)return res.status(400).json({error:'INVALID_USER_ID'});if(!amount||Number(amount)<=0)return res.status(400).json({error:'INVALID_AMOUNT'});const member=await pool.query("SELECT 1 FROM trip_members WHERE trip_id=$1 AND user_id=$2 AND status='joined'",[req.trip.id,payerId]);if(!member.rowCount)return res.status(400).json({error:'NOT_TRIP_MEMBER',message:'Payment user must be a joined member of this trip'});const q=await pool.query('INSERT INTO payments(trip_id,user_id,amount,note) VALUES($1,$2,$3,$4) RETURNING *',[req.trip.id,payerId,Number(amount),note||null]);res.status(201).json({payment:q.rows[0]});}));
app.get('/api/trips/:id/fund',auth,tripAccess,asyncHandler(async(req,res)=>{const q=await pool.query(`SELECT COALESCE(SUM(amount),0)::numeric total_paid, COUNT(*)::int payment_count FROM payments WHERE trip_id=$1 AND status='paid'`,[req.trip.id]);const by=await pool.query(`SELECT u.id,u.display_name,COALESCE(SUM(p.amount),0)::numeric paid FROM trip_members tm JOIN users u ON u.id=tm.user_id LEFT JOIN payments p ON p.user_id=u.id AND p.trip_id=$1 AND p.status='paid' WHERE tm.trip_id=$1 GROUP BY u.id,u.display_name ORDER BY u.display_name`,[req.trip.id]);res.json({target:req.trip.fund_target,total_paid:q.rows[0].total_paid,payment_count:q.rows[0].payment_count,members:by.rows});}));
app.get('/api/trips/:id/payments',auth,tripAccess,asyncHandler(async(req,res)=>{const q=await pool.query('SELECT p.*,u.display_name FROM payments p JOIN users u ON u.id=p.user_id WHERE p.trip_id=$1 ORDER BY p.paid_at DESC',[req.trip.id]);res.json({data:q.rows});}));
app.delete('/api/trips/:id/payments/:paymentId',auth,tripAccess,asyncHandler(async(req,res)=>{const q=await pool.query('DELETE FROM payments WHERE id=$1 AND trip_id=$2 AND user_id=$3 RETURNING id',[req.params.paymentId,req.trip.id,req.user.id]);if(!q.rowCount)return res.status(404).json({error:'PAYMENT_NOT_FOUND_OR_FORBIDDEN'});res.json({message:'Payment deleted'});}));

app.use((req,res)=>res.status(404).json({error:'NOT_FOUND',message:'Endpoint not found'}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'INTERNAL_SERVER_ERROR',message:'Unexpected server error'});});

app.listen(PORT,()=>console.log(`TripMate API listening on port ${PORT}`));
