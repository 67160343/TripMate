# TripMate

TripMate เป็นระบบจัดการทริปที่ประกอบด้วย REST API, PostgreSQL และ Frontend

## โครงสร้างโปรเจกต์

- tripmate-api/     Backend REST API
- tripmate-frontend/ Frontend HTML
- tripmate-api/db/init.sql     Database schema

## สิ่งที่ต้องติดตั้ง

ก่อนเริ่มใช้งาน ต้องมี:

- Docker Desktop
- Python 3
- Web Browser เช่น Chrome

## 1. เปิด Backend

เปิด CMD แล้วเข้าโฟลเดอร์:

cd tripmate-api

จากนั้นรัน:

docker compose up --build

ห้ามปิดหน้าต่าง CMD นี้ขณะทดสอบระบบ

## 2. ตรวจสอบ Backend

เปิด Browser แล้วเข้า:

http://localhost:3000/health

ถ้าระบบทำงานถูกต้อง ควรเห็น:

{"status":"ok","service":"tripmate-api",...}

## 3. เปิด Frontend

เปิด CMD อีกหน้าต่างหนึ่ง

เข้าโฟลเดอร์:

cd tripmate-frontend

จากนั้นรัน:

py -m http.server 5500

แล้วเปิด Browser:

http://localhost:5500/tripmate_frontend_api.html

## 4. สร้างบัญชีผู้ใช้

เมื่อเปิดหน้า Login:

1. เลือกสร้างผู้ใช้งานใหม่
2. กรอก Display Name
3. กรอก Username
4. กรอก Email
5. กรอก Password
6. ยืนยัน Password
7. สมัครสมาชิก

จากนั้นสามารถ Login ด้วยบัญชีที่สร้างขึ้นได้

## 5. การพัฒนา Backend

Backend อยู่ใน:

tripmate-api/src/server.js

Database schema อยู่ใน:

tripmate-api/db/init.sql

Docker configuration อยู่ใน:

tripmate-api/docker-compose.yml

## 6. Database

ระบบใช้ PostgreSQL ผ่าน Docker

Database schema ถูกสร้างจาก:

tripmate-api/db/init.sql

ไฟล์ init.sql เป็น schema สำหรับสร้างฐานข้อมูลใหม่ ไม่ใช่ database backup

## 7. Environment

ไฟล์ .env.example เป็นตัวอย่าง configuration

ห้ามนำ secret หรือ credential จริงใส่ใน repository

ไฟล์ .env ถ้ามี ต้องไม่ส่งต่อและไม่ควร commit เข้า Git

## 8. การหยุดระบบ

เมื่อทดสอบเสร็จ สามารถหยุด Docker ได้ด้วย:

docker compose down

คำสั่งนี้หยุดและลบ container/network ของ Compose แต่ไม่ได้ใช้แทนการ backup database

## 9. ข้อควรระวัง

- อย่าแก้ไขไฟล์ในโปรเจกต์หลักของเจ้าของงานโดยตรง
- อย่าแชร์ password จริง
- อย่าแชร์ API key จริง
- อย่าแชร์ไฟล์ .env ที่มี secret จริง
- ก่อนแก้ Database ควรทำ backup
- หลังแก้ฟีเจอร์ควรทดสอบ API และ Frontend

## 10. จุดเริ่มต้นสำหรับพัฒนาต่อ

แนะนำให้เริ่มจาก:

1. ตรวจสอบ Backend
2. ตรวจสอบ Authentication
3. ตรวจสอบ Trips
4. ตรวจสอบ Members
5. ตรวจสอบ Activities
6. ตรวจสอบ Accommodations
7. ตรวจสอบ Payments
8. จากนั้นจึงเพิ่มฟีเจอร์ใหม่
